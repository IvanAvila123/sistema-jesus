<?php
class AdminModel extends Query{
    public function __construct()
    {
        parent::__construct();
    }

    public function getClientes(){

        $sql = "SELECT * FROM clientes";
        return $this->selectAll($sql);

    }

    public function getVerificar($item, $telefono, $id)
    {
        if ($id !== null) {
            $sql = "SELECT id FROM clientes WHERE $item = '$telefono'AND id != $id";
        } else {
            $sql = "SELECT id FROM clientes WHERE $item = '$telefono'";
        }

         return $this->select($sql);
        
    }

    public function registrar($nombre, $apellido, $telefono, $domicilio) {

        $sql = "INSERT INTO clientes (nombre, apellido, telefono, domicilio) VALUES (?,?,?,?)";
        $datos = array($nombre, $apellido, $telefono, $domicilio);
        return $this->insertar($sql,$datos);

    }

    public function getCliente($id){

        $sql = "SELECT id ,nombre, apellido, telefono, domicilio FROM clientes WHERE id = $id ";
        return $this->select($sql);
    }

    public function modificar($nombre, $apellido, $telefono, $direccion, $id) {

        $sql = "UPDATE clientes SET nombre=?, apellido=?, telefono=?, domicilio=? WHERE id=? ";
        $datos = array($nombre, $apellido, $telefono, $direccion, $id);
        return $this->save($sql,$datos);

    }

    public function delete($id)
{
    $sql = "DELETE FROM clientes WHERE id = ?";
    $datos = array($id);
    $result = $this->save($sql,$datos);

    if ($result) {
        return $id;
    } else {
        return "Error al Eliminar";
    }
}

public function getDetalle($id){
    $sql = "SELECT * FROM detalle WHERE id = $id";
    $data = $this->selectAll($sql);
    return $data;
}

}

?>