<?php
const BASE_URL = "http://localhost/sistema-jesus/";
const HOST = "localhost";
const USER = "root";
const PASS = "";
const DB = "servicio_avila";
const CHARSET = "charset=utf8";
?>