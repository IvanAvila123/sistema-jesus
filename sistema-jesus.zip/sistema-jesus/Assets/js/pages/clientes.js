const frm = document.querySelector('#formulario');
const btnNuevo = document.querySelector('#btnNuevo');
const title = document.querySelector('#title');


const modalRegistro = document.querySelector("#modalRegistro");

const myModal = new bootstrap.Modal(modalRegistro);

let tblClientes;

document.addEventListener('DOMContentLoaded', function() {

  tblClientes = $('#tblClientes').DataTable({
    ajax: {
        url: base_url + 'admin/listar',
        dataSrc: ''
    },
    columns: [
        { data: 'nombre' },
        { data: 'apellido' },
        { data: 'telefono' },
        { data: 'domicilio' },
        { data: 'acciones' }

    ],
    language: {
        url: 'https://cdn.datatables.net/plug-ins/1.13.2/i18n/es-ES.json'
    },
    responsive: true,
    order: [[1, 'desc']],
});


btnNuevo.addEventListener('click', function () {
  title.textContent = 'Nuevo Cliente';
  frm.id_cliente.value = '';
  frm.removeAttribute('readonly');
  frm.reset();
  myModal.show();
})



    //registrar usuario por AJAX

    frm.addEventListener('submit', function (e) {
      e.preventDefault();
      if (frm.nombre.value === '' || frm.apellido.value === ''
         || frm.telefono.value === ''|| frm.domicilio.value === '') {
           alertaPerzonalizada ('warning', 'Todos los campos son requeridos');
      } else {

          const data = new FormData(frm);
          const http = new XMLHttpRequest();

          const url = base_url + 'admin/guardar';

          http.open("POST", url, true);

          http.send(data);

          http.onreadystatechange = function () {

              if (this.readyState == 4 && this.status == 200) {

                  const res = JSON.parse(this.responseText);
                  alertaPerzonalizada(res.tipo, res.mensaje);
                  if (res.tipo == 'success') {
                      frm.reset();
                      myModal.hide();
                      tblClientes.ajax.reload();
                  }

              }

          }

      }
  })
})
  

function editar(id) {
    const http = new XMLHttpRequest();
    const url = base_url + 'admin/editar/' + id;
    http.open("GET", url, true);
    http.send();
    http.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        try {
          const res = JSON.parse(this.responseText);
          title.textContent = 'Editar Cliente';
          frm.id_cliente.value = res.id;
          frm.nombre.value = res.nombre;
          frm.apellido.value = res.apellido;
          frm.telefono.value = res.telefono;
          frm.domicilio.value = res.domicilio;
          myModal.show();
        } catch (error) {
          console.error("Error al analizar JSON:", error.message, "\nJSON:", this.responseText);
        }
      }
    };
  }
  




  function eliminar(id) {
    const url = base_url + 'admin/delete/' + id
    eliminarRegistro('Esta Seguro De Eliminar', 'El Cliente Se Eliminara De Forma Permanente', 'Si Eliminar', url, tblClientes);
}

function ver(id) {
  const url = base_url + 'admin/listar/' + id;
  window.location.href = url;
}


  



