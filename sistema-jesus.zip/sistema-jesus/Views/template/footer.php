</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
            </div>
        </div>

    <script src="<?php echo BASE_URL . "Assets/vendor/global/global.min.js"?>"></script>
	<script src="<?php echo BASE_URL . "Assets/vendor/chart.js/Chart.bundle.min.js"?>"></script>
	<script src="<?php echo BASE_URL . "Assets/vendor/jquery-nice-select/js/jquery.nice-select.min.js"?>"></script>
	
	<!-- Apex Chart -->
	<script src="<?php echo BASE_URL . "Assets/vendor/apexchart/apexchart.js"?>"></script>
	<script src="<?php echo BASE_URL . "Assets/vendor/nouislider/nouislider.min.js"?>"></script>
	<script src="<?php echo BASE_URL . "Assets/vendor/wnumb/wNumb.js"?>"></script>

	<script>
        const base_url = '<?php echo BASE_URL; ?>';
    </script>
	
	<!-- Dashboard 1 -->
	<script src="<?php echo BASE_URL . "Assets/js/dashboard/dashboard-1.js"?>"></script>

    <script src="<?php echo BASE_URL . "Assets/js/custom.min.js"?>"></script>
	<script src="<?php echo BASE_URL . "Assets/js/dlabnav-init.js"?>"></script>
	<script src="<?php echo BASE_URL . "Assets/js/demo.js"?>"></script>
    <script src="<?php echo BASE_URL . "Assets/js/styleSwitcher.js"?>"></script>
	<script src="<?php echo BASE_URL . "Assets/js/sweetalert2@11.js" ?>"></script>
	<script src="<?php echo BASE_URL ."Assets/js/select2.min.js" ?>"></script>
	<script type="text/javascript" src="<?php echo BASE_URL . "Assets/vendor/DataTables/datatables.min.js" ?>"></script>
	<script src="<?php echo BASE_URL . "Assets/js/custom.js" ?>"></script>
	<?php if (!empty($data['script'])) { ?>
    <script src="<?php echo BASE_URL . "Assets/js/pages/" . $data['script']; ?>"></script>
    <?php } ?>
	
</body>
</html>