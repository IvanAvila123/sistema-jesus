<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="keywords" content="admin, dashboard">
	<meta name="author" content="DexignZone">
	<meta name="robots" content="index, follow">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Dompet : Payment Admin Template">
	<meta property="og:title" content="Dompet : Payment Admin Template">
	<meta property="og:description" content="Dompet : Payment Admin Template">
	<meta property="og:image" content="https://dompet.dexignlab.com/xhtml/social-image.png">
	<meta name="format-detection" content="telephone=no">
	
	<!-- PAGE TITLE HERE -->
	<title><?php echo $data['title']; ?></title>
	
	<!-- FAVICONS ICON -->
	<link rel="shortcut icon" type="<?php echo BASE_URL . 'Assets/image/png'; ?>" href="<?php echo BASE_URL . 'Assets/images/#'; ?>">
    <link href="<?php echo BASE_URL . 'Assets/css/style.css'; ?>" rel="stylesheet">

</head>

<body class="vh-100">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
									<div class="text-center mb-3">
										<a href="index.html"><img src="<?php echo BASE_URL . 'Assets/images/#'; ?>" alt=""></a>
									</div>
                                    <h4 class="text-center mb-4">Bienvenido Al Sistema De Servicio Avila</h4>
                                    <form id="formulario" autocomplete="off">
                                        <div class="mb-3">
                                            <label class="mb-1"><strong>Email</strong><span class="text-danger">*</span></label>
                                            <input type="email" class="form-control" id ="correo" name="correo" placeholder="Correo Electronico">
                                        </div>
                                        <div class="mb-3">
                                            <label class="mb-1"><strong>Contraseña</strong><span class="text-danger">*</span></label>
                                            <input type="password" class="form-control" id ="clave" name="clave" placeholder="Contraseña">
                                        </div>
                                        
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary btn-block">Entrar</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="<?php echo BASE_URL . 'Assets/vendor/global/global.min.js'; ?>"></script>
    <script src="<?php echo BASE_URL . 'Assets/js/sweetalert2@11.js'; ?>"></script>
    <script src="<?php echo BASE_URL . 'Assets/js/custom.js'; ?>"></script>
    <script>
       const base_url = '<?php echo BASE_URL; ?>';
    </script>
    <script src="<?php echo BASE_URL . 'Assets/js/pages/login.js'; ?>"></script>
    <script src="<?php echo BASE_URL . 'Assets/js/custom.min.js'; ?>"></script>
    <script src="<?php echo BASE_URL . 'Assets/js/dlabnav-init.js'; ?>"></script>
	<script src="<?php echo BASE_URL . 'Assets/js/styleSwitcher.js'; ?>"></script>
</body>
</html>