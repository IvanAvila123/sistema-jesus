<?php
class Admin extends Controller
{
    private $id_cliente, $correo;
    public function __construct() {
        parent::__construct();
        session_start();
        $this->id_cliente = $_SESSION['id'];
        $this->correo = $_SESSION ['correo'];
    }

    public function index() {
    
     $data['title'] = 'Panel De Clientes';
     $data['script'] = 'clientes.js';
     $this->views->getView('admin', 'home', $data); 
    }

    public function listar() {
        $data = $this->model->getClientes();
        for ($i = 0; $i < count($data); $i++) {
            if ($data[$i]['id'] == 1) {
            } else {
                $data[$i]['acciones'] = '<div>
                <a href="#" class="btn btn-info btn-xs" onclick="editar(' . $data[$i]['id'] . ')"><i class="material-icons">edit</i></a>
    
                <a href="#" class="btn btn-danger btn-xs" onclick="eliminar(' . $data[$i]['id'] . ')"><i class="material-icons">delete</i></a>

                <a href="'.BASE_URL.'Admin/detalle/'.$data[$i]['id'].'" class="btn btn-primary btn-xs"><i class="material-icons">visibility</i></a>
                </div>';
            }
        }
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        die();
    }

    public function guardar()
    {
        
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $telefono = $_POST['telefono'];
        $domicilio = $_POST['domicilio'];
        $id_cliente = $_POST['id_cliente'];

        if (empty($nombre) || empty($apellido) || empty($telefono) || empty($domicilio)) {
            $res = array('tipo' => 'warning', 'mensaje' => 'Todos Los Campos Son Requeridos');
        } else {
            if ($id_cliente == '') {
                    ###comprobar si existe telefono###
                    $verificarTel = $this->model->getVerificar('telefono', $telefono, 0);
                    if (empty($verificarTel)) {
                        $data = $this->model->registrar($nombre, $apellido, $telefono, $domicilio,);
                        if ($data > 0) {
                            $res = array('tipo' => 'success', 'mensaje' => 'Cliente Registrado');
                        } else {
                            $res = array('tipo' => 'error', 'mensaje' => 'Error al Registrar');
                        }
                    } else {
                        $res = array('tipo' => 'warning', 'mensaje' => 'El Telefono Ya Existe');
                    }

                } else {

                    $verificarTel = $this->model->getVerificar('telefono', $telefono, $id_cliente);
                    if (empty($verificarTel)) {
                        $data = $this->model->modificar($nombre, $apellido, $telefono, $domicilio, $id_cliente);
                        if ($data == 1) {
                            $res = array('tipo' => 'success', 'mensaje' => 'Cliente Modificado');
                        } else {
                            $res = array('tipo' => 'error', 'mensaje' => 'Error al Modificar');
                        }

                        } else {
                        $res = array('tipo' => 'warning', 'mensaje' => 'El Telefono Ya Existe');
                        }

                }
            }
        
        echo json_encode($res, JSON_UNESCAPED_UNICODE);
        die();
    }

    public function editar($id){
        
        $data = $this->model->getCliente($id);
    
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        die();
      }

    public function delete($id){

        $data = $this->model->delete($id);
        if ($data == $id) {
            $res =array('tipo' => 'success', 'mensaje' => 'Cliente Eliminado');
        }else{
    
        $res =array('tipo' => 'warning', 'mensaje' => 'Error Al Eliminar');
    }
    echo json_encode($res, JSON_UNESCAPED_UNICODE);
        
    }

    public function detalle($id) {
        $data = $this->model->getDetalle($id);
        $data['title'] = 'Detalles Clientes';
        $this->views->getView('Admin', 'detalles', $data); 
    }

    
}
?>
