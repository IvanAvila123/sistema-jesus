<?php
class Detalle extends Controller
{
    private $id_cliente, $correo;
    public function __construct() {
        parent::__construct();
        session_start();
        $this->id_cliente = $_SESSION['id'];
        $this->correo = $_SESSION ['correo'];
    }

    public function index() {
    
     $data['title'] = 'Detalles Del Cliente';
     $this->views->getView('detalles', 'detalles_cliente', $data); 
    }

    

}

?>